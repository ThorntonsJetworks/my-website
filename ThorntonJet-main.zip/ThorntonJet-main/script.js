// ===== Mobile Nav Toggle =====
const toggle = document.querySelector('.mobile-toggle');
const navLinks = document.querySelector('.nav-links');

toggle.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

// Close nav on link click
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => navLinks.classList.remove('active'));
});

// ===== Calendar =====
const calendarGrid = document.getElementById('calendarGrid');
const calendarMonth = document.getElementById('calendarMonth');
const prevBtn = document.getElementById('prevMonth');
const nextBtn = document.getElementById('nextMonth');
const selectedDateInput = document.getElementById('selectedDate');
const selectedDateDisplay = document.getElementById('selectedDateDisplay');

const today = new Date();
let currentMonth = today.getMonth();
let currentYear = today.getFullYear();
let selectedDate = null;

const monthNames = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

function renderCalendar(month, year) {
  calendarGrid.innerHTML = '';
  calendarMonth.textContent = `${monthNames[month]} ${year}`;

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Adjust so Monday = 0
  const startDay = firstDay === 0 ? 6 : firstDay - 1;

  // Empty cells before first day
  for (let i = 0; i < startDay; i++) {
    const empty = document.createElement('button');
    empty.className = 'day empty';
    empty.disabled = true;
    calendarGrid.appendChild(empty);
  }

  // Day buttons
  for (let d = 1; d <= daysInMonth; d++) {
    const btn = document.createElement('button');
    btn.className = 'day';
    btn.textContent = d;
    btn.type = 'button';

    const thisDate = new Date(year, month, d);

    // Disable past dates
    if (thisDate < new Date(today.getFullYear(), today.getMonth(), today.getDate())) {
      btn.classList.add('disabled');
      btn.disabled = true;
    }

    // Highlight today
    if (d === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
      btn.classList.add('today');
    }

    // Highlight selected
    if (selectedDate && d === selectedDate.getDate() && month === selectedDate.getMonth() && year === selectedDate.getFullYear()) {
      btn.classList.add('selected');
    }

    btn.addEventListener('click', () => {
      selectedDate = new Date(year, month, d);
      const formatted = selectedDate.toLocaleDateString('en-GB', {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
      });
      selectedDateDisplay.textContent = formatted;
      selectedDateInput.value = selectedDate.toISOString().split('T')[0];
      renderCalendar(currentMonth, currentYear);
    });

    calendarGrid.appendChild(btn);
  }
}

prevBtn.addEventListener('click', () => {
  currentMonth--;
  if (currentMonth < 0) { currentMonth = 11; currentYear--; }
  renderCalendar(currentMonth, currentYear);
});

nextBtn.addEventListener('click', () => {
  currentMonth++;
  if (currentMonth > 11) { currentMonth = 0; currentYear++; }
  renderCalendar(currentMonth, currentYear);
});

renderCalendar(currentMonth, currentYear);

// ===== Form Submission =====
const form = document.getElementById('bookingForm');

form.addEventListener('submit', (e) => {
  e.preventDefault();

  if (!selectedDateInput.value) {
    selectedDateDisplay.textContent = 'Please select a date first';
    selectedDateDisplay.style.color = '#ef4444';
    setTimeout(() => {
      selectedDateDisplay.style.color = '';
      selectedDateDisplay.textContent = 'Select a date from the calendar';
    }, 2500);
    return;
  }

  const data = new FormData(form);
  const details = Object.fromEntries(data.entries());

  // Replace this with your actual form handler (email service, backend API, etc.)
  console.log('Booking request:', details);

  // Show success
  form.innerHTML = `
    <div style="text-align:center; padding:40px 0;">
      <h3 style="margin-bottom:12px; color: var(--accent);">Quote Requested!</h3>
      <p style="color: var(--gray);">Thanks ${details.name}! We'll be in touch shortly to confirm your quote on <strong>${selectedDateDisplay.textContent}</strong>.</p>
    </div>
  `;
});

// ===== Smooth scroll offset for fixed nav =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      const offset = 80;
      const top = target.getBoundingClientRect().top + window.pageYOffset - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});
